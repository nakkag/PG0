//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// pg0edit.rc �Ŏg�p
//
#define IDS_STRING_OPEN_TITLE           10
#define IDS_STRING_SAVE_TITLE           11
#define IDS_STRING_MSG_MODIFY           12
#define IDS_STRING_CONSOLE_START        13
#define IDS_STRING_CONSOLE_END          14
#define IDS_STRING_CONSOLE_STOP         15
#define IDS_STRING_CONSOLE_RESULT       16
#define IDS_STRING_HEADER_NAME          17
#define IDS_STRING_HEADER_VALUE         18
#define IDS_STRING_CONFIRM_TUTORIAL     19
#define IDI_ICON_MAIN                   102
#define IDR_MENU                        103
#define IDR_ACCELERATOR                 106
#define IDR_TOOLBAR                     107
#define ID_MENUITEM_OPEN                40001
#define ID_MENUITEM_SAVEAS              40002
#define ID_MENUITEM_CLOSE               40003
#define ID_MENUITEM_UNDO                40009
#define ID_MENUITEM_REDO                40010
#define ID_MENUITEM_COPY                40011
#define ID_MENUITEM_CUT                 40012
#define ID_MENUITEM_PASTE               40013
#define ID_MENUITEM_DELETE              40014
#define ID_MENUITEM_SELECT_ALL          40015
#define ID_MENUITEM_FONT                40016
#define ID_MENUITEM_WORDWRAP            40017
#define ID_MENUITEM_SAVE                40018
#define ID_MENUITEM_NEW                 40019
#define ID_MENUITEM_EXEC                40020
#define ID_MENUITEM_CLEAR               40021
#define ID_MENUITEM_STOP                40022
#define ID_MENUITEM_NO_WAIT             40023
#define ID_MENUITEM_SPEED_HIGH          40024
#define ID_MENUITEM_SPEED_MID           40025
#define ID_MENUITEM_SPEED_LOW           40026
#define ID_MENUITEM_STEP                40027
#define ID_BUTTON_RUN                   40029
#define ID_BUTTON_STEP                  40031
#define ID_BUTTON_STOP                  40032
#define ID_MENUITEM_RUN_TO_CURSOR       40034
#define ID_MENUITEM_ABOUT               40035
#define ID_MENUITEM_TUTORIAL            40036
#define ID_MENUITEM_PG05                40037
#define ID_40040                        40040
#define ID_MENUITEM_FIND                40041
#define ID_40044                        40044
#define ID_MENUITEM_FINDNEXT            40045
#define ID_ACCELERATOR40046             40046

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40048
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
