/*
 * PG0
 *
 * functbl.c
 *
 * Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

/* Include Files */
#include <windows.h>
#include <tchar.h>

#include "script.h"
#include "script_string.h"


/* Local Function Prototypes */
//func_error.c
int SFUNC _sfunc_error(EXECINFO *ei, char *param, int *ret, char *ErrStr);

/* Global Variables */
typedef struct _FUNCTBL {
	char *name;
	int name_hash;
	LIBFUNC func;
} FUNCTBL;

FUNCTBL ft[] = {
	"_sfunc_error", 0, _sfunc_error,
};

/*
 * InitFuncAddress - �֐��e�[�u���̏�����
 */
void InitFuncAddress()
{
	int i;

	for(i = 0; i < sizeof(ft) / sizeof(FUNCTBL); i++){
		(ft + i)->name_hash = str2hash((ft + i)->name);
	}
}

/*
 * GetFuncAddress - �֐�������A�h���X���擾
 */
LIBFUNC GetFuncAddress(char *FuncName)
{
	int name_hash;
	int i;

	name_hash = str2hash(FuncName);
	for(i = 0; i < sizeof(ft) / sizeof(FUNCTBL); i++){
		if((ft + i)->name_hash == name_hash && tstrcmp((ft + i)->name, FuncName) == 0){
			return (ft + i)->func;
		}
	}
	return NULL;
}
/* End of source */
