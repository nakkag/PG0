/*
 * PG0
 *
 * script_utility.h
 *
 * Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef SCRIPT_UTILITY_H
#define SCRIPT_UTILITY_H

/* Include Files */
#include <windows.h>

/* Define */

/* Struct */

/* Function Prototypes */
VALUEINFO *IntToVariable(TCHAR *name, const int i);
int VariableToInt(VALUEINFO *vi);
VALUEINFO *StringToVariable(TCHAR *name, const TCHAR *buf);
TCHAR *VariableToString(VALUEINFO *vi);

#endif
/* End of source */
