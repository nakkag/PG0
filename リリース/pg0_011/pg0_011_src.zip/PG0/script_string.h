/*
 * PG0
 *
 * script_string.h
 *
 * Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef SCRIPT_STRING_H
#define SCRIPT_STRING_H

/* Include Files */
#include <windows.h>
#include <tchar.h>

/* Define */

/* Struct */

/* Function Prototypes */
char *tchar2char(const TCHAR *str);
TCHAR *char2tchar(const char *str);
TCHAR *str_cpy(TCHAR *ret, const TCHAR *buf);
TCHAR *str_cpy_n(TCHAR *ret, TCHAR *buf, const int len);
int str_cmp_n(const TCHAR *buf1, const TCHAR *buf2, const int len);
int str_cmp_i(const TCHAR *buf1, const TCHAR *buf2);
int str_cmp_ni(const TCHAR *buf1, const TCHAR *buf2, const int len);
BOOL str_match(const TCHAR *Ptn, const TCHAR *Str);
TCHAR *f2a(double f);
TCHAR *i2a(long i);
long x2d(const TCHAR *str);
long o2d(const TCHAR *str);
BOOL conv_ctrl(TCHAR *buf);
TCHAR *reconv_ctrl(TCHAR *buf);
TCHAR *str_skip(TCHAR *p, TCHAR end);
TCHAR *get_pair_brace(TCHAR *buf);
BOOL str_trim(TCHAR *buf);
void str_lower(TCHAR *p);
int str2hash(TCHAR *str);

#endif
/* End of source */
