/*
 * PG0cmd
 *
 * main.c
 *
 * Copyright (C) 1996-2018 by Nakashima Tomoaki. All rights reserved.
 *		http://www.nakka.com/
 *		nakka@nakka.com
 */

/* Include Files */
#include <windows.h>
#include <stdio.h>
#include <locale.h>

#include "../PG0/script.h"
#include "../PG0/script_string.h"
#include "../PG0/script_memory.h"
#include "../PG0/script_utility.h"

/* Define */
#define BUF_SIZE	256
#define LINE_SIZE	32768

/* Global Variables */
TCHAR AppDir[MAX_PATH + 1];
BOOL op_pg0 = FALSE;
BOOL op_hex = FALSE;

/* Local Function Prototypes */

/*
 * _lib_func_error - �G���[�o��
 */
int SFUNC _lib_func_error(EXECINFO *ei, VALUEINFO *param, VALUEINFO *ret, TCHAR *ErrStr)
{
	TCHAR *str;
	int line = 0;

	if (param == NULL) {
		return -2;
	}
	str = VariableToString(param);
	_tprintf(TEXT("%s\n"), str);
	mem_free(&str);
	return 0;
}

/*
 * _lib_func_print - �W���o��
 */
int SFUNC _lib_func_print(EXECINFO *ei, VALUEINFO *param, VALUEINFO *ret, TCHAR *ErrStr)
{
	TCHAR *str;

	if (param == NULL) {
		return -2;
	}
	str = VariableToString(param);
	_tprintf(TEXT("%s"), str);
	mem_free(&str);
	return 0;
}

/*
 * _lib_func_input - �W������
 */
int SFUNC _lib_func_input(EXECINFO *ei, VALUEINFO *param, VALUEINFO *ret, TCHAR *ErrStr)
{
	HANDLE ih;
	TCHAR *buf, *p;
	int mode, rmode;
	int size;
	int len = 1024;

	//�W�����͂��當�����ǂݎ��
	ih = GetStdHandle(STD_INPUT_HANDLE);
	GetConsoleMode(ih, &mode);
	rmode = mode;
	//�s���̓��[�h�ɐݒ�
	mode |= ENABLE_LINE_INPUT;
	SetConsoleMode(ih, mode);
	buf = mem_alloc(sizeof(TCHAR) * (len + 1));
	ReadConsole(ih, buf, len, &size, NULL);
	SetConsoleMode(ih, rmode);

	*(buf + size) = TEXT('\0');
	for (p = buf; *p != TEXT('\0') && *p != TEXT('\r') && *p != TEXT('\n'); p++);
	*p = TEXT('\0');

	ret->v->u.Value = buf;
	ret->v->Type = TYPE_STRING;
	return 0;
}

/*
 * FormatValue - �l�̏o��
 */
void FormatValue(VALUEINFO *vi) {
	if (op_hex == TRUE) {
		_tprintf(TEXT("0x%X"), vi->v->u.iValue);
	} else {
		_tprintf(TEXT("%d"), vi->v->u.iValue);
	}
}

/*
 * OutputArray - �z��̏o��
 */
void _OutputArray(VALUEINFO *vi) {
	BOOL first = TRUE;
	for (; vi != NULL; vi = vi->next) {
		if (first != TRUE) {
			_tprintf(TEXT(","));
		}
		first = FALSE;
		switch (vi->v->Type) {
		case TYPE_ARRAY:
			_tprintf(TEXT("{"));
			_OutputArray(vi->v->u.array);
			_tprintf(TEXT("}"));
			break;
		case TYPE_STRING:
			_tprintf(TEXT("%s"), vi->v->u.Value);
			break;
		case TYPE_FLOAT:
			_tprintf(TEXT("%.16f"), vi->v->u.fValue);
			break;
		default:
			FormatValue(vi);
			break;
		}
	}
}
void OutputArray(VALUEINFO *vi) {
	_tprintf(TEXT("{"));
	_OutputArray(vi);
	_tprintf(TEXT("}"));
}

/*
 * LineExecLoop - �P�s���͂���́A���s���s��
 */
static void LineExecLoop(BOOL debug)
{
	SCRIPTINFO *sci;
	EXECINFO ei;
	VALUEINFO *vi;
	VALUEINFO *svi = NULL;
	TOKEN *tk;
	TCHAR buf[LINE_SIZE];
	int ret = 0;

	sci = mem_alloc(sizeof(SCRIPTINFO));
	InitializeScriptInfo(sci, FALSE, !op_pg0);

	ZeroMemory(&ei, sizeof(EXECINFO));
	ei.Name = TEXT("stdin");
	ei.sci = sci;
	ei.line_mode = TRUE;

	while (_fgetts(buf, LINE_SIZE - 1, stdin) != NULL) {
		//���
		sci->buf = buf;
		tk = ParseSentence(&ei, buf, 1);
		if (tk == NULL) {
			continue;
		}
		//���s
		svi = NULL;
		ret = ExecSentense(&ei, tk, NULL, &svi, NULL);
		FreeToken(tk);
		if (ret == RET_EXIT || ret == RET_RETURN) {
			FreeValueList(svi);
			break;
		}
		if (ret != RET_ERROR) {
			vi = svi;
			while (vi != NULL) {
				switch (vi->v->Type) {
				case TYPE_ARRAY:
					OutputArray(vi->v->u.array);
					break;
				case TYPE_STRING:
					_tprintf(TEXT("%s"), vi->v->u.Value);
					break;
				case TYPE_FLOAT:
					_tprintf(TEXT("%.16f"), vi->v->u.fValue);
					break;
				default:
					FormatValue(vi);
					break;
				}
				_tprintf(TEXT("\n"));
				vi = vi->next;
			}
		}
		FreeValueList(svi);
	}
	FreeExecInfo(&ei);
	sci->buf = NULL;
	FreeScriptInfo(sci);
}

/*
 * _tmain - ���C��
 */
int _tmain(int argc, TCHAR **argv)
{
	SCRIPTINFO *ScriptInfo;
	VALUEINFO *vi, *pvi;
	VALUEINFO *rvi = NULL;
	TCHAR fname[MAX_PATH];
	int i = 1;
	int ret;
	TCHAR *c;
	BOOL op_debug = FALSE;
	BOOL op_explicit = FALSE;

	setlocale(LC_CTYPE, "");

	if (argc > i && (*(argv[i]) == TEXT('/') || *(argv[i]) == TEXT('-'))) {
		//help
		for (c = argv[i]; *c != TEXT('\0') && *c != TEXT('?'); c++);
		if (*c != TEXT('\0')) {
			WORD lang = PRIMARYLANGID(LANGIDFROMLCID(GetThreadLocale()));
			if (lang == LANG_JAPANESE) {
				_tprintf(TEXT("pg0cmd [/pex] [file.ns] [arg1[ arg2...]]\n"));
				_tprintf(TEXT("\n"));
				_tprintf(TEXT("  e\t\t�ϐ��錾������ (�ʏ���s��)\n"));
				_tprintf(TEXT("  x\t\t���ʂ�16�i���ŕ\��\n"));
				_tprintf(TEXT("\n"));
				_tprintf(TEXT("  file.pg0\t���s�A��͂��s���X�N���v�g�t�@�C��\n"));
				_tprintf(TEXT("         \t�t�@�C�����̎w�肪�����ꍇ�̓��C�����s���s��\n"));
				_tprintf(TEXT("\n"));
				_tprintf(TEXT("  arg1\t\t�X�N���v�g�ɓn������\n"));
				_tprintf(TEXT("\n"));
			} else {
				_tprintf(TEXT("pg0cmd [/pex] [file.ns] [arg1[ arg2...]]\n"));
				_tprintf(TEXT("\n"));
				_tprintf(TEXT("  e\t\tExplicit\n"));
				_tprintf(TEXT("  x\t\tHex result\n"));
				_tprintf(TEXT("\n"));
				_tprintf(TEXT("  file.pg0\tExecution script file\n"));
				_tprintf(TEXT("\n"));
				_tprintf(TEXT("  arg1\t\tCommand line\n"));
				_tprintf(TEXT("\n"));
			}
			return 0;
		}
		//PG0
		for (c = argv[i]; *c != '\0' && *c != 'p' && *c != '0'; c++);
		if (*c != '\0') {
			op_pg0 = TRUE;
		}
		//explicit
		for (c = argv[i]; *c != '\0' && *c != 'e' && *c != 'E'; c++);
		if (*c != '\0') {
			op_explicit = TRUE;
		}
		//hex
		for (c = argv[i]; *c != '\0' && *c != 'x' && *c != 'X'; c++);
		if (*c != '\0') {
			op_hex = TRUE;
		}
		i++;
	}

	if (argc <= i) {
		//1�s���s���[�h
		InitializeScript();
		LineExecLoop(op_debug);
		EndScript();
#ifdef _DEBUG
		mem_debug();
#endif
		return 0;
	}

	GetFilePathName(argv[i], AppDir, fname);
	SetCurrentDirectory(AppDir);
	i++;

	//������
	InitializeScript();

	//�ǂݍ���
	ScriptInfo = mem_calloc(sizeof(SCRIPTINFO));
	if (ScriptInfo == NULL) {
		return -1;
	}
	InitializeScriptInfo(ScriptInfo, op_explicit, !op_pg0);
	ScriptInfo->sci_top = ScriptInfo;
	ReadScriptFile(ScriptInfo, AppDir, fname);
	if (ScriptInfo->tk == NULL) {
		FreeScriptInfo(ScriptInfo);
#ifdef _DEBUG
		mem_debug();
#endif
		return -1;
	}

	//����
	if (argc <= i) {
		pvi = NULL;
	} else {
		int arg_cnt = argc - i;
		// argv
		pvi = AllocValue();
		if (pvi == NULL) {
			return -1;
		}
		pvi->Name = alloc_copy(TEXT("argv"));
		pvi->name_hash = str2hash(TEXT("argv"));
		vi = pvi->v->u.array = StringToVariable(NULL, argv[i]);
		for (i++; i < argc; i++) {
			vi = vi->next = StringToVariable(NULL, argv[i]);
		}
		// argc
		pvi->next = AllocValue();
		if (pvi->next == NULL) {
			return -1;
		}
		pvi->next->Name = alloc_copy(TEXT("argc"));
		pvi->next->name_hash = str2hash(TEXT("argc"));
		pvi->next->v->u.iValue = arg_cnt;
	}
	//�߂�l�̊m��
	rvi = NULL;
	ret = ExecScript(ScriptInfo, pvi, &rvi, NULL);
	if (ret != -1 && rvi != NULL && rvi->v != NULL) {
		switch (rvi->v->Type) {
		case TYPE_ARRAY:
			OutputArray(rvi->v->u.array);
			break;
		case TYPE_STRING:
			_tprintf(TEXT("%s"), rvi->v->u.Value);
			break;
		case TYPE_FLOAT:
			_tprintf(TEXT("%.16f"), rvi->v->u.fValue);
			break;
		default:
			FormatValue(rvi);
			break;
		}
		_tprintf(TEXT("\n"));
	}
	FreeValueList(rvi);
	FreeScriptInfo(ScriptInfo);
	EndScript();
#ifdef _DEBUG
	mem_debug();
#endif
	return 0;
}