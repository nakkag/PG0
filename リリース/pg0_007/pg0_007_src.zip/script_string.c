/**************************************************************************

	PG0

	script_string.c

	Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
		https://www.nakka.com/
		nakka@nakka.com

**************************************************************************/

/**************************************************************************
	Include Files
**************************************************************************/

#include <windows.h>
#include <tchar.h>

#include "script_memory.h"
#include "script_string.h"


/**************************************************************************
	Define
**************************************************************************/

#define ToLower(c)				((c >= 'A' && c <= 'Z') ? (c - 'A' + 'a') : c)


/**************************************************************************
	Global Variables
**************************************************************************/

/**************************************************************************
	Local Function Prototypes
**************************************************************************/


/******************************************************************************

	AllocTcharToChar

	���������m�ۂ��� char �� char �ɕϊ�����

******************************************************************************/

char *tchar2char(const TCHAR *str)
{
#ifdef UNICODE
	char *cchar;
	int len;

	if(str == NULL){
		return NULL;
	}
	len = WideCharToMultiByte(CP_ACP, 0, str, -1, NULL, 0, NULL, NULL);
	cchar = (char *)mem_alloc(len + 1);
	if(cchar == NULL){
		return NULL;
	}
	WideCharToMultiByte(CP_ACP, 0, str, -1, cchar, len, NULL, NULL);
	return cchar;
#else
	return alloc_copy(str);
#endif
}


/******************************************************************************

	AllocCharToTchar

	���������m�ۂ��� char �� char �ɕϊ�����

******************************************************************************/

TCHAR *char2tchar(const char *str)
{
#ifdef UNICODE
	TCHAR *tchar;
	int len;

	if(str == NULL){
		return NULL;
	}
	len = MultiByteToWideChar(CP_ACP, 0, str, -1, NULL, 0);
	tchar = (TCHAR *)mem_alloc(sizeof(TCHAR) * (len + 1));
	if(tchar == NULL){
		return NULL;
	}
	MultiByteToWideChar(CP_ACP, 0, str, -1, tchar, len);
	return tchar;
#else
	return alloc_copy(str);
#endif
}


/******************************************************************************

	str_cpy

	��������R�s�[���čŌ�̕����̃A�h���X��Ԃ�

******************************************************************************/

char *str_cpy(char *ret, const char *buf)
{
	if(buf == NULL){
		*ret = '\0';
		return ret;
	}
	while(*(ret++) = *(buf++));
	ret--;
	return ret;
}


/******************************************************************************

	str_cpy_n

	�w�肳�ꂽ�������܂ŕ�������R�s�[����

******************************************************************************/

char *str_cpy_n(char *ret, char *buf, const int len)
{
	int i = len;

	if(buf == NULL || len <= 0){
		*ret = '\0';
		return ret;
	}
	while(--i && (*(ret++) = *(buf++)));
	*ret = '\0';
	if(i != 0) ret--;
	return ret;
}


/******************************************************************************

	str_cmp_n

	�Q�̕�����𕶎�������r���s��

******************************************************************************/

int str_cmp_n(const char *buf1, const char *buf2, const int len)
{
	int i = 0;

	for(; *buf1 == *buf2 && *buf1 != '\0' && i < len; i++, buf1++, buf2++);
	return ((i == len) ? 0 : *buf1 - *buf2);
}


/******************************************************************************

	str_cmp_i

	������̑啶������������ʂ��Ȃ���r���s��

******************************************************************************/

int str_cmp_i(const char *buf1, const char *buf2)
{
	for(; ToLower(*buf1) == ToLower(*buf2) && *buf1 != '\0'; buf1++, buf2++);
	return ToLower(*buf1) - ToLower(*buf2);
}


/******************************************************************************

	str_cmp_ni

	�Q�̕������啶���A����������ʂ��Ȃ��Ŕ�r���s��

******************************************************************************/

int str_cmp_ni(const char *buf1, const char *buf2, const int len)
{
	int i = 0;

	for(; ToLower(*buf1) == ToLower(*buf2) && *buf1 != '\0' && i < len; i++, buf1++, buf2++);
	return ((i == len) ? 0 : ToLower(*buf1) - ToLower(*buf2));
}


/******************************************************************************

	str_match

	�Q�̕���������C���h�J�[�h(*)���g���Ĕ�r���s��

******************************************************************************/

BOOL str_match(const char *Ptn, const char *Str)
{
	switch(*Ptn)
	{
	case '\0':
		return (*Str == '\0');
	case '*':
		return str_match(Ptn + 1, Str) || (*Str != '\0') && str_match(Ptn, Str + 1);
	case '?':
		return (*Str != '\0') && str_match(Ptn + 1, Str + 1);
	default:
		return (ToLower(*Ptn) == ToLower(*Str)) && str_match(Ptn + 1, Str + 1);
	}
}


/******************************************************************************

	i2a

	���l��10�i�\�L�̕�����ɕϊ�����

******************************************************************************/

static char *ri2a(char *p, long i)
{
    if(i / 10 != 0){
		p = ri2a(p, i / 10);
	}
	i %= 10;
    *(p++) = '0' + (char)((i < 0) ? (i * -1) : i);
	return p;
}
char *i2a(long i)
{
	char *buf;
	char *p, *r;
	long j = i;
	int cnt = 1;

	while((j = j / 10) != 0){
		cnt++;
	}

	p = buf = mem_alloc(sizeof(char) * (cnt + 2));
	if (buf == NULL) {
		return NULL;
	}
	if(i < 0){
		*(p++) = '-';
	}
	r = ri2a(p, i);
	*r = '\0';
	return buf;
}


/******************************************************************************

	x2d

	16�i�\�L�̕�����𐔒l�ɕϊ�����

******************************************************************************/

long x2d(const char *str)
{
	int num = 0;
	int m;

	for(; *str != '\0'; str++){
		if(*str >= '0' && *str <= '9'){
			m = *str - '0';
		}else if(*str >= 'A' && *str <= 'F'){
			m = *str - 'A' + 10;
		}else if(*str >= 'a' && *str <= 'f'){
			m = *str - 'a' + 10;
		}else{
			break;
		}
		num = 16 * num + m;
	}
	return num;
}


/******************************************************************************

	o2d

	8�i�\�L�̕�����𐔒l�ɕϊ�����

******************************************************************************/

long o2d(const char *str)
{
	int num = 0;
	int m;

	for(; *str != '\0'; str++){
		if(*str >= '0' && *str <= '7'){
			m = *str - '0';
		}else{
			break;
		}
		num = 8 * num + m;
	}
	return num;
}


/******************************************************************************

	conv_ctrl

	���䕶����ϊ�

******************************************************************************/

BOOL conv_ctrl(char *buf)
{
	char *p, *r, *s;
	char tmp[10];

	if(buf == NULL){
		return FALSE;
	}

	p = buf;
	while(*p != '\0'){
		if(IsDBCSLeadByte((BYTE)*p) == TRUE && *(p + 1) != '\0'){
			//2�o�C�g�R�[�h���X�L�b�v
			p += 2;
			continue;
		}
		if(*p == '\\' && *(p + 1) != '\0'){
			//���䕶���̕ϊ�
			r = p + 1;
			switch(*r)
			{
			case 'r':
				//CR
				r++;
				*(p++) = '\r';
				break;

			case 'n':
				//LF
				r++;
				*(p++) = '\n';
				break;

			case 't':
				//�^�u
				r++;
				*(p++) = '\t';
				break;

			case 'b':
				//�o�b�N�X�y�[�X
				r++;
				*(p++) = '\b';
				break;

			case 'x':
				//Char (Hex)
				r++;
				if(*r != '\0'){
					for(s = r; (s - r) < 2 && ((*s >= '0' && *s <= '9')
						|| (*s >= 'A' && *s <= 'F')
						|| (*s >= 'a' && *s <= 'f')); s++);
					str_cpy_n(tmp, r, s - r + 1);
					*(p++) = (unsigned char)x2d(tmp);
					r += s - r;
				}
				break;

			case '\"':
				r++;
				*(p++) = '\"';
				break;

			case '\\':
				r++;
				*(p++) = '\\';
				break;

			default:
				if(*r >= '0' && *r <= '7'){
					//Char (Oct)
					for(s = r; (s - r) < 3 && (*s >= '0' && *s <= '7'); s++);
					str_cpy_n(tmp, r, s - r + 1);
					*(p++) = (char)o2d(tmp);
					r += s - r;
					break;
				}else{
					p++;
				}
				continue;
			}
			tstrcpy(p, r);

		}else{
			p++;
		}
	}
	return TRUE;
}


/******************************************************************************

	reconv_ctrl

	\ �� \\ �ɕϊ�

******************************************************************************/

char *reconv_ctrl(char *buf)
{
	char *ret, *p, *r;
	int len;

	for(p = buf, len = 0; *p != '\0'; p++, len++){
		if(IsDBCSLeadByte((BYTE)*p) == TRUE && *(p + 1) != '\0'){
			p++;
			len++;
		}else if(*p == '\\'){
			len++;
		}
	}
	ret = mem_alloc(len + 1);
	if(ret == NULL){
		return NULL;
	}
	for(p = buf, r = ret; *p != '\0'; p++){
		if(IsDBCSLeadByte((BYTE)*p) == TRUE && *(p + 1) != '\0'){
			*(r++) = *(p++);
		}else if(*p == '\\'){
			*(r++) = *p;
		}
		*(r++) = *p;
	}
	*r = '\0';
	return ret;
}


/******************************************************************************

	str_skip

	������̏I���ʒu�̎擾

******************************************************************************/

char *str_skip(char *p)
{
	//������̓X�L�b�v
	for(p++; *p != '\0' && *p != '\"'; p++){
		if(IsDBCSLeadByte((BYTE)*p) == TRUE && *(p + 1) != '\0'){
			//2�o�C�g�R�[�h���X�L�b�v
			p++;
			if(*p == '\0') break;
			continue;
		}
		if(*p == '\\'){
			p++;
			if(*p == '\0'){
				break;
			}
		}
	}
	return p;
}


/******************************************************************************

	GetPairtBrace

	�Ή����銇�ʂ��擾

******************************************************************************/

char *get_pair_brace(char *buf)
{
	char sc, ec;
	int k_cnt = 1;

	sc = *buf;
	switch(sc)
	{
	case '{':
		ec = '}';
		break;

	case '(':
		ec = ')';
		break;

	case '[':
		ec = ']';
		break;

	default:
		return NULL;
	}

	for(buf++; *buf != '\0'; buf++){
		if(IsDBCSLeadByte((BYTE)*buf) == TRUE && *(buf + 1) != '\0'){
			//2�o�C�g�R�[�h���X�L�b�v
			buf++;
			if(*buf == '\0'){
				break;
			}
			continue;
		}
		if(*buf == '\"'){
			//������̓X�L�b�v
			buf = str_skip(buf);
			if(*buf == '\0'){
				break;
			}
		}
		if(*buf == '/' && *(buf + 1) == '/'){
			//�R�����g���X�L�b�v
			for(; *buf != '\0' && *buf != '\r' && *buf != '\n'; buf++);
			if(*buf == '\0'){
				break;
			}
		}
		if(*buf == sc){
			k_cnt++;
		}else if(*buf == ec){
			k_cnt--;
		}
		if(k_cnt == 0) break;
	}
	return ((k_cnt == 0) ? buf : NULL);
}


/******************************************************************************

	str_trim

	������̑O��̋�, Tab����������

******************************************************************************/

BOOL str_trim(char *buf)
{
	char *p, *r;

	//�O��̋󔒂��������|�C���^���擾
	for(p = buf; (*p == ' ' || *p == '\t') && *p != '\0'; p++);
	for(r = buf + tstrlen(buf) - 1; (*r == ' ' || *r == '\t') && r > p; r--);
	*(r + 1) = '\0';

	//���̕�����ɃR�s�[���s��
	tstrcpy(buf, p);
	return TRUE;
}


/******************************************************************************

	str_lower

	��������������ɕϊ�

******************************************************************************/

void str_lower(char *p)
{
	for(; *p != '\0'; p++){
		*p = ToLower(*p);
	}
}


/******************************************************************************

	str2hash

	������̃n�b�V���l���擾

******************************************************************************/

int str2hash(char *str)
{
	int hash = 0;

	if(str == NULL) return 0;

	for(; *str != '\0'; str++){
		hash = ((hash << 1) + *str);
	}
	return hash;
}
/* End of source */
