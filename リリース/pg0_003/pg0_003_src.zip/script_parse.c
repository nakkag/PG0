/**************************************************************************

	PG0

	script_parse.c

	Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
		https://www.nakka.com/
		nakka@nakka.com

**************************************************************************/

/**************************************************************************
	Include Files
**************************************************************************/

#include <windows.h>

#include "script.h"
#include "script_string.h"
#include "script_memory.h"


/**************************************************************************
	Define
**************************************************************************/

#define IS_SPACE(c)				(c == ' ' || c == '\t' || c == '\r' || c == '\n')


/**************************************************************************
	Global Variables
**************************************************************************/

typedef struct _PARSEINFO {
	EXECINFO *ei;
	int type;
	int level;
	char *p;
	char *r;
	BOOL concat;
	BOOL decl;
	int line;
	int bclose_line;
} PARSEINFO;


/**************************************************************************
	Local Function Prototypes
**************************************************************************/

static BOOL GetToken(PARSEINFO *pi);
static TOKEN *CreateToken(int type, char *p, int line);

//��
static TOKEN *Primary(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *Array(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *UnaryOperator(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *Multiplicative(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *Additive(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *Shift(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *Relational(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *Equality(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *AND(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *ExclusiveOR(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *OR(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *LogicalAND(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *LogicalOR(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *Assignment(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *Expression(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *ExpressionStatement(PARSEINFO *pi, TOKEN *cu_tk);

//����
static TOKEN *Condition(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *IfStatement(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *WhileStatement(PARSEINFO *pi, TOKEN *cu_tk);

static TOKEN *JumpStatement(PARSEINFO *pi, TOKEN *cu_tk);

//��`
static TOKEN *VarDeclList(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *VarDecl(PARSEINFO *pi, TOKEN *cu_tk);

//�\��
static TOKEN *CompoundStatement(PARSEINFO *pi, TOKEN *cu_tk);
static TOKEN *StatementList(PARSEINFO *pi, TOKEN *cu_tk);


/******************************************************************************

	GetToken

	������

******************************************************************************/

static BOOL GetToken(PARSEINFO *pi)
{
	char *s;

	for(pi->p = pi->r; IS_SPACE(*pi->p); pi->p++) {
		if (*pi->p == '\n') {
			pi->line++;
		}
	}
	pi->r = pi->p;
	pi->type = 0;

	switch(*pi->p)
	{
	case '\0':
		pi->type = SYM_EOF;
		return TRUE;

	case ';':
		pi->type = SYM_LINEEND;
		pi->concat = TRUE;
		break;

	case ',':
		pi->type = SYM_WORDEND;
		pi->concat = TRUE;
		break;

	case '{':
		if(pi->concat == FALSE){
			Error(pi->ei, ERR_SENTENCE_PREV, pi->p, NULL);
			return FALSE;
		}
		if(get_pair_brace(pi->p) == NULL){
			Error(pi->ei, ERR_BRACE, pi->p, NULL);
			return FALSE;
		}
		pi->type = SYM_BOPEN;
		pi->concat = TRUE;
		break;

	case '}':
		pi->type = SYM_BCLOSE;
		pi->concat = FALSE;
		pi->bclose_line = pi->line;
		break;

	case '(':
		if(pi->concat == FALSE){
			Error(pi->ei, ERR_SENTENCE_PREV, pi->p, NULL);
			return FALSE;
		}
		if(get_pair_brace(pi->p) == NULL){
			Error(pi->ei, ERR_BRACE, pi->p, NULL);
			return FALSE;
		}
		pi->type = SYM_OPEN;
		pi->concat = TRUE;
		break;

	case ')':
		pi->type = SYM_CLOSE;
		pi->concat = FALSE;
		break;

	case '[':
		if(pi->concat == TRUE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		if(get_pair_brace(pi->p) == NULL){
			Error(pi->ei, ERR_BRACE, pi->p, NULL);
			return FALSE;
		}
		pi->type = SYM_ARRAYOPEN;
		pi->concat = TRUE;
		break;

	case ']':
		pi->type = SYM_ARRAYCLOSE;
		pi->concat = FALSE;
		break;

	case '=':
		if(pi->concat == TRUE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		switch(*(pi->p + 1))
		{
		case '=':
			pi->type = SYM_EQEQ;
			pi->r++;
			break;

		default:
			pi->type = SYM_EQ;
			break;
		}
		pi->concat = TRUE;
		break;

	case '!':
		if(pi->concat == TRUE){
			pi->type = SYM_NOT;
			break;
		}
		if(*(pi->p + 1) == '='){
			pi->type = SYM_NTEQ;
			pi->r++;
		}else{
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		pi->concat = TRUE;
		break;

	case '<':
		if(pi->concat == TRUE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		if(*(pi->p + 1) == '='){
			pi->type = SYM_LEFTEQ;
			pi->r++;
		}else{
			pi->type = SYM_LEFT;
		}
		pi->concat = TRUE;
		break;

	case '>':
		if(pi->concat == TRUE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		if(*(pi->p + 1) == '='){
			pi->type = SYM_RIGHTEQ;
			pi->r++;
		}else{
			pi->type = SYM_RIGHT;
		}
		pi->concat = TRUE;
		break;

	case '&':
		if(pi->concat == TRUE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		if(*(pi->p + 1) == '&'){
			pi->type = SYM_CPAND;
			pi->r++;
		}else{
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		pi->concat = TRUE;
		break;

	case '|':
		if(pi->concat == TRUE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		if(*(pi->p + 1) == '|'){
			pi->type = SYM_CPOR;
			pi->r++;
		}else{
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		pi->concat = TRUE;
		break;

	case '*':
		if(pi->concat == TRUE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		pi->type = SYM_MULTI;
		pi->concat = TRUE;
		break;

	case '/':
		if(*(pi->p + 1) == '/'){
			//�R�����g
			for(; *pi->r != '\0' && *pi->r != '\r' && *pi->r != '\n'; pi->r++);
			return GetToken(pi);
		}
		if(pi->concat == TRUE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		pi->type = SYM_DIV;
		pi->concat = TRUE;
		break;

	case '%':
		if(pi->concat == TRUE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return FALSE;
		}
		pi->type = SYM_MOD;
		pi->concat = TRUE;
		break;

	case '+':
		if(pi->concat == TRUE){
			if(*(pi->p + 1) == '+'){
				Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
				return FALSE;
			}else{
				pi->type = SYM_PLUS;
			}
			break;
		}
		pi->type = SYM_ADD;
		pi->concat = TRUE;
		break;

	case '-':
		if(pi->concat == TRUE){
			if(*(pi->p + 1) == '-'){
				Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
				return FALSE;
			}else{
				pi->type = SYM_MINS;
			}
			break;
		}
		pi->type = SYM_SUB;
		pi->concat = TRUE;
		break;
	}

	if(pi->type != 0){
		pi->r++;
		return TRUE;
	}
	if(pi->concat == FALSE){
		Error(pi->ei, ERR_SENTENCE_PREV, pi->p, NULL);
		return FALSE;
	}
	pi->concat = FALSE;

	if((*pi->p >= '0' && *pi->p <= '9') ||
		(*pi->p == '.' && *(pi->p + 1) >= '0' && *(pi->p + 1) <= '9')){
		//�萔
		pi->type = SYM_CONST;
		for(pi->r++; (*pi->r >= '0' && *pi->r <= '9') || *pi->r == '.'; pi->r++);
		return TRUE;
	}

	pi->r = pi->p;
	for(; (*pi->r >= 'a' && *pi->r <= 'z') || (*pi->r >= 'A' && *pi->r <= 'Z') ||
		(*pi->r >= '0' && *pi->r <= '9') || *pi->r == '_'; pi->r++);
	if(pi->p == pi->r){
		Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
		return FALSE;
	}
	s = alloc_copy_n(pi->p, pi->r - pi->p + 1);
	if(s == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return FALSE;
	}

	//�\���
	if(str_cmp_i(s, "var") == 0){
		pi->type = SYM_VAR;
	}else if(str_cmp_i(s, "exit") == 0){
		pi->type = SYM_EXIT;
	}else if(str_cmp_i(s, "if") == 0){
		pi->type = SYM_IF;
	}else if(str_cmp_i(s, "else") == 0){
		pi->type = SYM_ELSE;
	}else if(str_cmp_i(s, "while") == 0){
		pi->type = SYM_WHILE;
	}
	mem_free(&s);
	if(pi->type != 0){
		pi->concat = TRUE;
		return TRUE;
	}

	//�ϐ�
	pi->type = SYM_VARIABLE;
	return TRUE;
}


/******************************************************************************

	CreateToken

	�g�[�N���̍쐬

******************************************************************************/

static TOKEN *CreateToken(int type, char *p, int line)
{
	TOKEN *tk;

	tk = mem_calloc(sizeof(TOKEN));
	if(tk == NULL){
		return NULL;
	}
	tk->Type = type;
	tk->line = line;
	tk->Err = p;
	return tk;
}


/******************************************************************************

	Primary

	�v�f

******************************************************************************/

static TOKEN *Primary(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN ttk;
	char *s;

	switch(pi->type)
	{
	case SYM_BOPEN:
		cu_tk = cu_tk->next = CreateToken(pi->type, pi->p, pi->line);
		if(cu_tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		cu_tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			return NULL;
		}
		ttk.next = NULL;
		if(Expression(pi, &ttk) == NULL){
			FreeToken(ttk.next);
			return NULL;
		}
		cu_tk->target = ttk.next;

		if(pi->type != SYM_BCLOSE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return NULL;
		}
		if(GetToken(pi) == FALSE){
			return NULL;
		}
		break;

	case SYM_OPEN:
		if(GetToken(pi) == FALSE){
			return NULL;
		}
		cu_tk = Assignment(pi, cu_tk);
		if(pi->type != SYM_CLOSE){
			Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
			return NULL;
		}
		if(GetToken(pi) == FALSE){
			return NULL;
		}
		break;

	case SYM_VARIABLE:
		//�ϐ�
		if(pi->decl == TRUE || pi->ei->decl == TRUE){
			//�ϐ��錾
			cu_tk = cu_tk->next = CreateToken(SYM_DECLVARIABLE, pi->p, pi->line);
		}else{
			cu_tk = cu_tk->next = CreateToken(pi->type, pi->p, pi->line);
		}
		if(cu_tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
		cu_tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
		if(cu_tk->buf == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
		if(GetToken(pi) == FALSE){
			return NULL;
		}
		break;

	case SYM_CONST:
		//���l�萔
		cu_tk = cu_tk->next = CreateToken(pi->type, pi->p, pi->line);
		if(cu_tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
		s = alloc_copy_n(pi->p, pi->r - pi->p + 1);
		if(s == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}

		if(*s != '0' || *(s + 1) == '\0'){
			//10�i��
			cu_tk->i = atoi(s);

		}else if(*(s + 1) == 'x' || *(s + 1) == 'X'){
			//16�i��
			cu_tk->i = x2d(s + 2);
		}else{
			//8�i��
			cu_tk->i = o2d(s + 1);
		}
		mem_free(&s);

		if(GetToken(pi) == FALSE){
			return NULL;
		}
		break;
	}
	return cu_tk;
}


/******************************************************************************

	Array

	�z��

******************************************************************************/

static TOKEN *Array(PARSEINFO *pi, TOKEN *cu_tk)
{
	cu_tk = Primary(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_ARRAYOPEN){
		if(GetToken(pi) == FALSE){
			return NULL;
		}
		if(pi->type != SYM_ARRAYCLOSE){
			//�v�f
			cu_tk = Assignment(pi, cu_tk);
			if(pi->type != SYM_ARRAYCLOSE){
				Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
				return NULL;
			}
			//�z�񎯕ʎq�̒ǉ�
			cu_tk = cu_tk->next = CreateToken(SYM_ARRAY, pi->p, pi->line);
			if(cu_tk == NULL){
				Error(pi->ei, ERR_ALLOC, pi->p, NULL);
				return NULL;
			}
#ifdef DEBUG_SET
			cu_tk->buf = alloc_copy("(Array)");
#endif
		}
		if(GetToken(pi) == FALSE){
			return NULL;
		}
		cu_tk = Primary(pi, cu_tk);
		if(cu_tk == NULL){
			return NULL;
		}
	}
	return cu_tk;
}


/******************************************************************************

	UnaryOperator

	�P�����Z�q

******************************************************************************/

static TOKEN *UnaryOperator(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk;

	cu_tk = Array(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_NOT || pi->type == SYM_PLUS || pi->type == SYM_MINS){

		tk = CreateToken(pi->type, pi->p, pi->line);
		if(tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		//�O�u
		if(GetToken(pi) == FALSE){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = UnaryOperator(pi, cu_tk);
		if(cu_tk == NULL){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = cu_tk->next = tk;
	}
	return cu_tk;
}


/******************************************************************************

	Multiplicative

	��Z�A���Z�A��]

******************************************************************************/

static TOKEN *Multiplicative(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk;

	cu_tk = UnaryOperator(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_MULTI || pi->type == SYM_DIV || pi->type == SYM_MOD){
		tk = CreateToken(pi->type, pi->p, pi->line);
		if(tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = UnaryOperator(pi, cu_tk);
		if(cu_tk == NULL){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = cu_tk->next = tk;
	}
	return cu_tk;
}


/******************************************************************************

	Additive

	���Z�A���Z

******************************************************************************/

static TOKEN *Additive(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk;

	cu_tk = Multiplicative(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_ADD || pi->type == SYM_SUB){
		tk = CreateToken(pi->type, pi->p, pi->line);
		if(tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = Multiplicative(pi, cu_tk);
		if(cu_tk == NULL){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = cu_tk->next = tk;
	}
	return cu_tk;
}


/******************************************************************************

	Relational

	��r (<, >, <=, >=)

******************************************************************************/

static TOKEN *Relational(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk;

	cu_tk = Additive(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_LEFT || pi->type == SYM_LEFTEQ ||
		pi->type == SYM_RIGHT || pi->type == SYM_RIGHTEQ){
		tk = CreateToken(pi->type, pi->p, pi->line);
		if(tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = Additive(pi, cu_tk);
		if(cu_tk == NULL){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = cu_tk->next = tk;
	}
	return cu_tk;
}


/******************************************************************************

	Equality

	��r (==, !=)

******************************************************************************/

static TOKEN *Equality(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk;

	cu_tk = Relational(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_EQEQ || pi->type == SYM_NTEQ){
		tk = CreateToken(pi->type, pi->p, pi->line);
		if(tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = Relational(pi, cu_tk);
		if(cu_tk == NULL){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = cu_tk->next = tk;
	}
	return cu_tk;
}


/******************************************************************************

	LogicalAND

	�_����

******************************************************************************/

static TOKEN *LogicalAND(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk;

	cu_tk = Equality(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_CPAND){
		tk = CreateToken(pi->type, pi->p, pi->line);
		if(tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = Equality(pi, cu_tk);
		if(cu_tk == NULL){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = cu_tk->next = tk;
	}
	return cu_tk;
}


/******************************************************************************

	LogicalOR

	�_���a

******************************************************************************/

static TOKEN *LogicalOR(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk;

	cu_tk = LogicalAND(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_CPOR){
		tk = CreateToken(pi->type, pi->p, pi->line);
		if(tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = LogicalAND(pi, cu_tk);
		if(cu_tk == NULL){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = cu_tk->next = tk;
	}
	return cu_tk;
}


/******************************************************************************

	Assignment

	�����

******************************************************************************/

static TOKEN *Assignment(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk;

	cu_tk = LogicalOR(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_EQ){
		tk = CreateToken(pi->type, pi->p, pi->line);
		if(tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = Assignment(pi, cu_tk);
		if(cu_tk == NULL){
			FreeToken(tk);
			return NULL;
		}
		cu_tk = cu_tk->next = tk;
	}
	return cu_tk;
}


/******************************************************************************

	Expression

	��1 , ��2

******************************************************************************/

static TOKEN *Expression(PARSEINFO *pi, TOKEN *cu_tk)
{
	cu_tk = Assignment(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	while(pi->type == SYM_WORDEND){
		cu_tk = cu_tk->next = CreateToken(pi->type, pi->p, pi->line);
		if(cu_tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		cu_tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			return NULL;
		}
		cu_tk = Assignment(pi, cu_tk);
		if(cu_tk == NULL){
			return NULL;
		}
	}
	return cu_tk;
}


/******************************************************************************

	ExpressionStatement

	�� ;

******************************************************************************/

static TOKEN *ExpressionStatement(PARSEINFO *pi, TOKEN *cu_tk)
{
	cu_tk = Expression(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	if(pi->type == SYM_EOF || pi->type == SYM_BCLOSE){
		return cu_tk;
	}
	if(pi->type != SYM_LINEEND){
		Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
		return NULL;
	}
	cu_tk = cu_tk->next = CreateToken(pi->type, pi->p, pi->line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
	if(GetToken(pi) == FALSE){
		return NULL;
	}
	return cu_tk;
}


/******************************************************************************

	Condition

	������

******************************************************************************/

static TOKEN *Condition(PARSEINFO *pi, TOKEN *cu_tk)
{
	// (
	if(GetToken(pi) == FALSE){
		return NULL;
	}
	if(pi->type != SYM_OPEN){
		Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
		return NULL;
	}
	if(GetToken(pi) == FALSE){
		return NULL;
	}
	if(pi->type == SYM_CLOSE){
		Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
		return NULL;
	}
	//������
	cu_tk = Assignment(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	// )
	if(pi->type != SYM_CLOSE){
		Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
		return NULL;
	}
	pi->concat = TRUE;
	if(GetToken(pi) == FALSE){
		return NULL;
	}
	return cu_tk;
}


/******************************************************************************

	IfStatement

	if��

******************************************************************************/

static TOKEN *IfStatement(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *end_tk, *else_tk;
	int line;

	//������
	line = pi->line;
	cu_tk = Condition(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	//CMP��ǉ�
	cu_tk = cu_tk->next = CreateToken(SYM_CMP, pi->p, line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("CMP");
#endif

	//ELSE�Ɉړ�
	else_tk = cu_tk = cu_tk->next = CreateToken(SYM_JUMP, pi->p, line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("jump ELSE");
#endif

	//�����Ώ�
	line = pi->bclose_line = pi->line;
	cu_tk = StatementList(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	if (line == pi->bclose_line) {
		line = pi->line;
	} else {
		line = pi->bclose_line;
	}

	//��r�I���ʒu�Ɉړ�
	end_tk = cu_tk = cu_tk->next = CreateToken(SYM_JUMP, pi->p, line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("jump CMPEND");
#endif

	//ELSE:
	else_tk->link = cu_tk = cu_tk->next = CreateToken(SYM_ELSE, pi->p, pi->line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("ELSE:");
#endif
	if(pi->type == SYM_ELSE){
		//�����Ώ�
		pi->concat = TRUE;
		if(GetToken(pi) == FALSE){
			return NULL;
		}
		line = pi->bclose_line = pi->line;
		cu_tk = StatementList(pi, cu_tk);
		if(cu_tk == NULL){
			return NULL;
		}
		if (line == pi->bclose_line) {
			line = pi->line;
		} else {
			line = pi->bclose_line;
		}
	}

	//��r�I���ʒu
	end_tk->link = cu_tk = cu_tk->next = CreateToken(SYM_CMPEND, pi->p, line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("CMPEND:");
#endif
	return cu_tk;
}


/******************************************************************************

	WhileStatement

	while��

******************************************************************************/

static TOKEN *WhileStatement(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *st_tk, *end_tk, ttk;
	int line;

	//���[�v�J�n�ʒu
	st_tk = cu_tk = cu_tk->next = CreateToken(SYM_LOOPSTART, pi->p, pi->line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("LOOPSTART:");
#endif

	//������
	line = pi->line;
	cu_tk = Condition(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	//LOOP��ǉ�
	cu_tk = cu_tk->next = CreateToken(SYM_LOOP, pi->p, line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("LOOP");
#endif

	//�����Ώ�
	ttk.next = NULL;
	line = pi->bclose_line = pi->line;
	if(StatementList(pi, &ttk) == NULL){
		FreeToken(ttk.next);
		return NULL;
	}
	cu_tk->target = ttk.next;
	if (line == pi->bclose_line) {
		line = pi->line;
	} else {
		line = pi->bclose_line;
	}

	//���[�v�I���ʒu�Ɉړ�
	end_tk = cu_tk = cu_tk->next = CreateToken(SYM_JUMP, pi->p, line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("jump LOOPEND");
#endif

	//���[�v�J�n�ʒu�Ɉړ�
	cu_tk = cu_tk->next = CreateToken(SYM_JUMP, pi->p, pi->bclose_line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("jump LOOPSTART");
#endif
	cu_tk->link = st_tk;

	//���[�v�I���ʒu
	end_tk->link = cu_tk = cu_tk->next = CreateToken(SYM_LOOPEND, pi->p, line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy("LOOPEND:");
#endif
	return cu_tk;
}


/******************************************************************************

	JumpStatement

	�W�����v

******************************************************************************/

static TOKEN *JumpStatement(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk;

	//token
	tk = CreateToken(pi->type, pi->p, pi->line);
	if(tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
	if(GetToken(pi) == FALSE){
		FreeToken(tk);
		return NULL;
	}
	
	//�l
	cu_tk = Assignment(pi, cu_tk);
	if(cu_tk == NULL){
		FreeToken(tk);
		return NULL;
	}
	cu_tk = cu_tk->next = tk;

	if(pi->type == SYM_EOF || pi->type == SYM_BCLOSE){
		return cu_tk;
	}
	if(pi->type != SYM_LINEEND){
		Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
		return NULL;
	}
	cu_tk = cu_tk->next = CreateToken(pi->type, pi->p, pi->line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
	if(GetToken(pi) == FALSE){
		return NULL;
	}
	return cu_tk;
}


/******************************************************************************

	VarDeclList

	�ϐ����X�g

******************************************************************************/

static TOKEN *VarDeclList(PARSEINFO *pi, TOKEN *cu_tk)
{
	while(1){
		//����
		pi->decl = TRUE;
		cu_tk = Array(pi, cu_tk);
		pi->decl = FALSE;
		if(cu_tk == NULL){
			return NULL;
		}

		if(pi->type == SYM_EQ){
			// = 
			cu_tk = Assignment(pi, cu_tk);
			if(cu_tk == NULL){
				return NULL;
			}
		}

		if(pi->type != SYM_WORDEND){
			break;
		}
		// ,
		cu_tk = cu_tk->next = CreateToken(pi->type, pi->p, pi->line);
		if(cu_tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			return NULL;
		}
#ifdef DEBUG_SET
		cu_tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		if(GetToken(pi) == FALSE){
			return NULL;
		}
	}
	return cu_tk;
}


/******************************************************************************

	VarDecl

	�ϐ�

******************************************************************************/

static TOKEN *VarDecl(PARSEINFO *pi, TOKEN *cu_tk)
{
	//var
	if(GetToken(pi) == FALSE){
		return NULL;
	}
	//�ϐ����X�g
	cu_tk = VarDeclList(pi, cu_tk);
	if(cu_tk == NULL){
		return NULL;
	}
	if(pi->type == SYM_EOF || pi->type == SYM_BCLOSE){
		return cu_tk;
	}
	if(pi->type != SYM_LINEEND){
		Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
		return NULL;
	}
	// ;
	cu_tk = cu_tk->next = CreateToken(pi->type, pi->p, pi->line);
	if(cu_tk == NULL){
		Error(pi->ei, ERR_ALLOC, pi->p, NULL);
		return NULL;
	}
#ifdef DEBUG_SET
	cu_tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
	if(GetToken(pi) == FALSE){
		return NULL;
	}
	return cu_tk;
}


/******************************************************************************

	CompoundStatement

	�u���b�N

******************************************************************************/

static TOKEN *CompoundStatement(PARSEINFO *pi, TOKEN *cu_tk)
{
	TOKEN *tk, ttk;

	if(GetToken(pi) == FALSE){
		return NULL;
	}
	//�u���b�N�̏I���ʒu�܂ŉ��
	ttk.next = NULL;
	tk = &ttk;
	while(tk != NULL && pi->type != SYM_EOF && pi->type != SYM_BCLOSE){
		tk = StatementList(pi, tk);
	}
	cu_tk->target = ttk.next;
	if(tk == NULL){
		return NULL;
	}
	if(pi->type != SYM_BCLOSE){
		Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
		return NULL;
	}
	pi->concat = TRUE;
	if(GetToken(pi) == FALSE){
		return NULL;
	}
	return cu_tk;
}


/******************************************************************************

	StatementList

	��

******************************************************************************/

static TOKEN *StatementList(PARSEINFO *pi, TOKEN *cu_tk)
{
	pi->level++;

	switch(pi->type)
	{
	case SYM_EOF:
		break;

	case SYM_BOPEN:
		//�u���b�N
		cu_tk = cu_tk->next = CreateToken(pi->type, pi->p, pi->line);
		if(cu_tk == NULL){
			Error(pi->ei, ERR_ALLOC, pi->p, NULL);
			break;
		}
#ifdef DEBUG_SET
		cu_tk->buf = alloc_copy_n(pi->p, pi->r - pi->p + 1);
#endif
		cu_tk = CompoundStatement(pi, cu_tk);
		break;

	case SYM_IF:
		cu_tk = IfStatement(pi, cu_tk);
		break;

	case SYM_WHILE:
		cu_tk = WhileStatement(pi, cu_tk);
		break;

	case SYM_EXIT:
		cu_tk = JumpStatement(pi, cu_tk);
		break;

	case SYM_VAR:
		//�ϐ�
		cu_tk = VarDecl(pi, cu_tk);
		break;

	case SYM_VARIABLE:
	case SYM_CONST:
	case SYM_OPEN:
	case SYM_NOT:
	case SYM_PLUS:
	case SYM_MINS:
	case SYM_WORDEND:
	case SYM_LINEEND:
		//��
		cu_tk = ExpressionStatement(pi, cu_tk);
		break;

	default:
		Error(pi->ei, ERR_SENTENCE, pi->p, NULL);
		cu_tk = NULL;
		break;
	}
	pi->level--;
	return cu_tk;
}


/******************************************************************************

	ParseVariable

	�ϐ��擾

******************************************************************************/

TOKEN *ParseVariable(EXECINFO *ei, char *buf)
{
	TOKEN tk;
	PARSEINFO pi;

	ZeroMemory(&pi, sizeof(PARSEINFO));
	pi.ei = ei;
	pi.p = pi.r = buf;
	pi.concat = TRUE;
	pi.level = 1;

	if(GetToken(&pi) == FALSE){
		return NULL;
	}

	//���
	ZeroMemory(&tk, sizeof(TOKEN));
	if(Array(&pi, &tk) == NULL || pi.type != SYM_EOF){
		//�G���[���͑S�ĉ��
		FreeToken(tk.next);
		return NULL;
	}
	return tk.next;
}


/******************************************************************************

	ParseSentence

	�\�����

******************************************************************************/

TOKEN *ParseSentence(EXECINFO *ei, char *buf, int level)
{
	TOKEN *cu_tk, tk;
	PARSEINFO pi;

	ZeroMemory(&pi, sizeof(PARSEINFO));
	pi.ei = ei;
	pi.p = pi.r = buf;
	pi.concat = TRUE;
	pi.level = level;

	if(GetToken(&pi) == FALSE){
		return NULL;
	}

	//���
	ZeroMemory(&tk, sizeof(TOKEN));
	cu_tk = &tk;
	while(cu_tk != NULL && pi.type != SYM_EOF){
		cu_tk = StatementList(&pi, cu_tk);
	}
	if(cu_tk == NULL){
		//�G���[���͑S�ĉ��
		FreeToken(tk.next);
		return NULL;
	}
	return tk.next;
}
/* End of source */
