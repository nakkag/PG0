/*
 * PG0
 *
 * script_memory.c
 *
 * Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

/* Include Files */
#include <windows.h>
#include <tchar.h>

#include "script_string.h"

/* Define */

/* Global Variables */
#ifdef _DEBUG
static SIZE_T all_alloc_size = 0;

//#define MEM_CHECK
#ifdef MEM_CHECK
#define ADDRESS_CNT		100000
#define DEBUG_ADDRESS	0
static long address[ADDRESS_CNT];
static int address_index;
#endif	//MEM_CHECK

#endif	//_DEBUG

/* Local Function Prototypes */

/*
 * mem_alloc - �o�b�t�@���m��
 */
void *mem_alloc(const int size)
{
#ifdef _DEBUG
	void *mem;

	mem = LocalAlloc(LMEM_FIXED, size);
	if (mem == NULL) {
		return mem;
	}
	all_alloc_size += LocalSize(mem);
#ifdef MEM_CHECK
	if (address_index < ADDRESS_CNT) {
		if (address_index == DEBUG_ADDRESS) {
			address[address_index] = (long)mem;
		} else {
			address[address_index] = (long)mem;
		}
		address_index++;
	}
#endif	//MEM_CHECK
	return mem;
#else	//_DEBUG
	return LocalAlloc(LMEM_FIXED, size);
#endif	//_DEBUG
}

/*
 * mem_calloc - �����������o�b�t�@���m��
 */
void *mem_calloc(const int size)
{
#ifdef _DEBUG
	void *mem;

	mem = LocalAlloc(LPTR, size);
	if (mem == NULL) {
		return mem;
	}
	all_alloc_size += LocalSize(mem);
#ifdef MEM_CHECK
	if (address_index < ADDRESS_CNT) {
		if (address_index == DEBUG_ADDRESS) {
			address[address_index] = (long)mem;
		} else {
			address[address_index] = (long)mem;
		}
		address_index++;
	}
#endif	//MEM_CHECK
	return mem;
#else	//_DEBUG
	return LocalAlloc(LPTR, size);
#endif	//_DEBUG
}

/*
 * mem_realloc - �o�b�t�@���Ċm��
 */
void *mem_realloc(void *mem, const int size)
{
#ifdef _DEBUG
	all_alloc_size -= LocalSize(mem);
	mem = LocalReAlloc(mem, size, LMEM_MOVEABLE);
	all_alloc_size += LocalSize(mem);
#ifdef MEM_CHECK
	if (address_index < ADDRESS_CNT) {
		if (address_index == DEBUG_ADDRESS) {
			address[address_index] = (long)mem;
		} else {
			address[address_index] = (long)mem;
		}
		address_index++;
	}
#endif	//MEM_CHECK
	return mem;
#else	//_DEBUG
	return LocalReAlloc(mem, size, LMEM_MOVEABLE);
#endif	//_DEBUG
}

/*
 * mem_free - �o�b�t�@�����
 */
void mem_free(void **mem)
{
	if (*mem != NULL) {
#ifdef _DEBUG
		all_alloc_size -= LocalSize(*mem);
#ifdef MEM_CHECK
		{
			int i;
			for (i = 0; i < ADDRESS_CNT; i++) {
				if (address[i] == (long)*mem) {
					address[i] = 0;
					break;
				}
			}
		}
#endif	//MEM_CHECK
#endif	//_DEBUG
		LocalFree(*mem);
		*mem = NULL;
	}
}

/*
 * mem_debug - ���������̕\��
 */
#ifdef _DEBUG
void mem_debug(void)
{
	TCHAR buf[256];

	if (all_alloc_size == 0) {
		return;
	}
	wsprintf(buf, TEXT("Memory leak: %lu bytes"), all_alloc_size);
	MessageBox(NULL, buf, TEXT("debug"), 0);
#ifdef MEM_CHECK
	{
		int i;
		for (i = 0; i < ADDRESS_CNT; i++) {
			if (address[i] != 0) {
				wsprintf(buf, TEXT("leak address: %u, %lu"), i, address[i]);
				MessageBox(NULL, buf, TEXT("debug"), 0);
				break;
			}
		}
	}
#endif	//MEM_CHECK
}
#endif	//_DEBUG

/*
 * alloc_copy - �o�b�t�@���m�ۂ��ĕ�������R�s�[����
 */
char *alloc_copy(const char *buf)
{
	char *ret;

	if (buf == NULL) {
		return NULL;
	}
	ret = (char *)mem_alloc(sizeof(char) * (tstrlen(buf) + 1));
	if (ret != NULL) {
		tstrcpy(ret, buf);
	}
	return ret;
}

/*
 * alloc_copy_n - �o�b�t�@���m�ۂ��Ďw�蒷�����̕�������R�s�[����
 */
char *alloc_copy_n(char *buf, const int size)
{
	char *ret;

	if (buf == NULL) {
		return NULL;
	}
	ret = (char *)mem_alloc(sizeof(char) * (size + 1));
	if (ret != NULL) {
		str_cpy_n(ret, buf, size);
	}
	return ret;
}

/*
 * alloc_join - �o�b�t�@���m�ۂ��ĕ������A������
 */
char *alloc_join(const char *buf1, const char *buf2)
{
	char *ret, *r;

	if (buf2 == NULL) {
		return alloc_copy(buf1);
	}
	if (buf1 == NULL) {
		return alloc_copy(buf2);
	}
	ret = mem_alloc(sizeof(char) * (tstrlen(buf1) + tstrlen(buf2) + 1));
	if (ret == NULL) {
		return NULL;
	}
	r = str_cpy(ret, buf1);
	tstrcpy(r, buf2);
	return ret;
}
/* End of source */
