/*
 * PG0
 *
 * script_utility.c
 *
 * Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

/* Include Files */
#include <windows.h>

#include "script.h"
#include "script_memory.h"
#include "script_string.h"

/* Define */

/* Global Variables */
static LCID lcid;

/* Local Function Prototypes */

/*
 * IntToVariable - ���l��ϐ��ɕϊ�
 */
VALUEINFO *IntToVariable(char *name, const int i)
{
	VALUEINFO *vi;

	vi = AllocValue();
	if (vi == NULL) {
		return NULL;
	}
	vi->Name = alloc_copy(name);
	vi->name_hash = str2hash(name);
	vi->v->iValue = i;
	return vi;
}

/*
 * VariableToInt - �ϐ��𐔒l�ɕϊ�
 */
int VariableToInt(VALUEINFO *vi)
{
	if (vi == NULL || vi->v == NULL) {
		return 0;
	}
	return GetValueInt(vi->v);
}
/* End of source */
