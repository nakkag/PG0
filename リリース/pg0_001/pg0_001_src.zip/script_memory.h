/**************************************************************************

	PG0

	script_memory.h

	Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
		https://www.nakka.com/
		nakka@nakka.com

**************************************************************************/

#ifndef SCRIPT_MEMORY_H
#define SCRIPT_MEMORY_H

/**************************************************************************
	Include Files
**************************************************************************/

#include <windows.h>


/**************************************************************************
	Define
**************************************************************************/

#ifdef _WIN32_WCE
#ifndef ZeroMemory
#define ZeroMemory(m, size)			memset(m, 0, size)
#endif
#ifndef CopyMemory
#define CopyMemory(t, f, size)		memcpy(t, f, size)
#endif
#endif


/**************************************************************************
	Struct
**************************************************************************/

/**************************************************************************
	Function Prototypes
**************************************************************************/

void *mem_alloc(const int size);
void *mem_calloc(const int size);
void mem_free(void **mem);
#ifdef _DEBUG
void mem_debug(void);
#endif
char *alloc_copy(const char *buf);
char *alloc_copy_n(char *buf, const int size);
char *alloc_join(const char *buf1, const char *buf2);

#endif
/* End of source */
