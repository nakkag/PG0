/*
 * PG0
 *
 * frame.c
 *
 * Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
 *		https://www.nakka.com/
 *		nakka@nakka.com
 */

/* Include Files */
#define _INC_OLE
#include <windows.h>
#undef	_INC_OLE

/* Define */
#define FRAME_CNT				1		// ���E�t���[����
#define NOMOVESIZE				6		// �t���[���̈ړ������l

/* Global Variables */

/* ocal Function Prototypes */

/*
 * frame_initialize - �t���[���̏�����
 */
BOOL frame_initialize(const HWND hWnd)
{
	SetCapture(hWnd);
	return TRUE;
}

/*
 * frame_free - �t���[���̉��
 */
void frame_free(void)
{
	ReleaseCapture();
}

/*
 * frame_draw_vertical - �t���[���̕`��
 */
int frame_draw_vertical(const HWND hWnd, const HWND hContainer)
{
	RECT window_rect, container_rect;
	POINT apos;

	GetCursorPos((LPPOINT)&apos);
	GetWindowRect(hWnd, (LPRECT)&window_rect);
	GetWindowRect(hContainer, (LPRECT)&container_rect);

	// �t���[���̈ړ�����
	if (apos.x <= (window_rect.left + NOMOVESIZE + GetSystemMetrics(SM_CXFRAME))) {
		apos.x = window_rect.left + NOMOVESIZE + GetSystemMetrics(SM_CXFRAME);
	} else if (apos.x >= (window_rect.right - (NOMOVESIZE + (FRAME_CNT * 2)) - GetSystemMetrics(SM_CXFRAME))) {
		apos.x = window_rect.right - (NOMOVESIZE + (FRAME_CNT * 2)) - GetSystemMetrics(SM_CXFRAME);
	}
	return (apos.x - window_rect.left) - GetSystemMetrics(SM_CXFRAME);
}

/*
 * frame_draw_horizon - �t���[���̕`��
 */
int frame_draw_horizon(const HWND hWnd, const HWND hContainer)
{
	RECT window_rect, container_rect;
	POINT apos;

	GetCursorPos((LPPOINT)&apos);
	GetWindowRect(hWnd, (LPRECT)&window_rect);
	GetWindowRect(hContainer, (LPRECT)&container_rect);

	// �t���[���̈ړ�����
	if (apos.y <= (window_rect.top + NOMOVESIZE + GetSystemMetrics(SM_CYFRAME))) {
		apos.y = window_rect.top + NOMOVESIZE + GetSystemMetrics(SM_CYFRAME);
	} else if (apos.y >= (window_rect.bottom - (NOMOVESIZE + (FRAME_CNT * 2)) - GetSystemMetrics(SM_CYFRAME))) {
		apos.y = window_rect.bottom - (NOMOVESIZE + (FRAME_CNT * 2)) - GetSystemMetrics(SM_CYFRAME);
	}
	return (apos.y - window_rect.top) - GetSystemMetrics(SM_CYFRAME);
}

/*
 * frame_draw_variable - �t���[���̕`��
 */
int frame_draw_variable(const HWND hWnd)
{
	RECT window_rect;
	POINT apos;

	GetCursorPos((LPPOINT)&apos);
	GetWindowRect(hWnd, (LPRECT)&window_rect);
	return (apos.x - window_rect.left) - GetSystemMetrics(SM_CXFRAME);
}
/* End of source */
