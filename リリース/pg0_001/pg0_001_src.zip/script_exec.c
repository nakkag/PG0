/**************************************************************************

	PG0

	script_exec.c

	Copyright (C) 1996-2018 by Ohno Tomoaki. All rights reserved.
		https://www.nakka.com/
		nakka@nakka.com

**************************************************************************/

/**************************************************************************
	Include Files
**************************************************************************/

#include <windows.h>
#include <tchar.h>

#ifndef _WIN32_WCE
#include <process.h>
#endif	//_WIN32_WCE

#include "script.h"
#include "script_string.h"
#include "script_memory.h"


/**************************************************************************
	Define
**************************************************************************/

#define RET_EXIT				-2
#define RET_ERROR				-1
#define RET_SUCCESS				0

#define STD_FUNC_HEAD			"_sfunc_"
#define SCRIPT_SEP				'.'


/**************************************************************************
	Global Variables
**************************************************************************/


/**************************************************************************
	Local Function Prototypes
**************************************************************************/

static VALUEINFO *IndexToArray(EXECINFO *ei, VALUEINFO *pvi, int index);
static VALUEINFO *DeclVariable(EXECINFO *ei, char *name, char *err);
static VALUEINFO *FindValueInfo(VALUEINFO *vi, char *name);
static VALUEINFO *AddValueInfo(VALUEINFO **vi_root, char *name, VALUE *v);

static TOKEN *FindCase(EXECINFO *ei, TOKEN *cu_tk, VALUEINFO *v1);
static VALUEINFO *UnaryCalcValue(EXECINFO *ei, VALUEINFO *vi, int c);
static VALUEINFO *IntegerCalcValue(EXECINFO *ei, VALUEINFO *v1, VALUEINFO *v2, int c);
static VALUEINFO *ArrayCalcValue(EXECINFO *ei, VALUEINFO *v1, VALUEINFO *v2, int c);
static VALUEINFO *CalcValue(EXECINFO *ei, VALUEINFO *v1, VALUEINFO *v2, int c);


/******************************************************************************

	InitializeScript

	�X�N���v�g�̏�����

******************************************************************************/

void InitializeScript()
{
	//�֐��e�[�u���̏�����
	InitFuncAddress();
}


/******************************************************************************

	EndScript

	�X�N���v�g�̏I������

******************************************************************************/

void EndScript()
{

}


/******************************************************************************

	Error

	�G���[

******************************************************************************/

void Error(EXECINFO *ei, char *buf, char *msg)
{
#define ERR_HEAD	"Error: "
	EXECINFO *pei = ei;
	LIBFUNC StdFunc;
	char *p, *r, *s, *t, *f;
	char ErrStr[BUF_SIZE];
	int i, ret = 0;

	for(; pei->parent != NULL; pei = pei->parent);

	//���b�Z�[�W
	f = p = alloc_join(ERR_HEAD, buf);
	if(msg != NULL && pei->sci != NULL && pei->sci->buf != NULL && msg >= pei->sci->buf && msg <= (pei->sci->buf + tstrlen(pei->sci->buf))){
		//�s����
		i = 1;
		for(s = r = pei->sci->buf; r < msg; r++){
			if(*r == '\n'){
				s = r;
				i++;
			}
		}
		//�s�ԍ�
		p = alloc_join(p, ":(");
		mem_free(&f);f = p;
		t = i2a(i);
		if (t != NULL) {
			p = alloc_join(p, t);
		}
		mem_free(&f);f = p;
		mem_free(&t);
		p = alloc_join(p, ") : ");
		mem_free(&f);f = p;

		//��
		for(; *s == '\r' || *s == '\n' || *s == '\t' || *s == ' '; s++);
		for(r = s; *r != '\0' && *r != '\r' && *r != '\n'; r++);
		t = alloc_copy_n(s, r - s + 1);
		p = alloc_join(p, t);
		mem_free(&f);f = p;
		mem_free(&t);

	}else if(msg != NULL){
		//���b�Z�[�W
		p = alloc_join(p, msg);
		mem_free(&f);f = p;
	}

	//�G���[���b�Z�[�W�̏o��
	StdFunc = GetFuncAddress("_sfunc_error");
	if(StdFunc == NULL){
		return;
	}
	*ErrStr = '\0';
	StdFunc(pei, p, &ret, ErrStr);
	mem_free(&p);
}


/******************************************************************************

	FreeToken

	�g�[�N���̉��

******************************************************************************/

void FreeToken(TOKEN *tk)
{
	if(tk == NULL) return;
	FreeToken(tk->target);
	FreeToken(tk->next);

	mem_free(&(tk->buf));
	mem_free(&tk);
}


/******************************************************************************

	FreeValue

	�ϐ��̉��

******************************************************************************/

void FreeValue(VALUEINFO *vi)
{
	if(vi == NULL || (int)vi == RET_ERROR || (int)vi == RET_EXIT) return;
	mem_free(&(vi->Name));
	if(vi->v != NULL && vi->v->vi == vi){
		mem_free(&(vi->v));
		FreeValueList(vi->array);
	}
	mem_free(&vi);
}


/******************************************************************************

	FreeValueList

	�ϐ����X�g�̉��

******************************************************************************/

void FreeValueList(VALUEINFO *vi)
{
	VALUEINFO *tmpvi;

	if((int)vi == -1) return;
	while(vi != NULL){
		tmpvi = vi->next;
		FreeValue(vi);
		vi = tmpvi;
	}
}


/******************************************************************************

	FreeExecInfo

	���s���̉��

******************************************************************************/

void FreeExecInfo(EXECINFO *ei)
{
	if(ei == NULL) return;
	FreeValueList(ei->vi);
	ei->vi = NULL;
	ei->Name = NULL;
}


/******************************************************************************

	FreeScriptInfo

	�X�N���v�g���̉��

******************************************************************************/

void FreeScriptInfo(SCRIPTINFO *sci)
{
	if(sci == NULL) return;
	FreeScriptInfo(sci->next);

	mem_free(&sci->name);
	mem_free(&sci->path);
	mem_free(&sci->buf);

	FreeToken(sci->tk);
	FreeValueList(sci->vi);

	mem_free(&sci);
}


/******************************************************************************

	InitializeScriptInfo

	�X�N���v�g���̏�����

******************************************************************************/

void InitializeScriptInfo(SCRIPTINFO *sci, BOOL op_exp)
{
	ZeroMemory(sci, sizeof(SCRIPTINFO));
	sci->sci_top = sci;
	sci->explicit_val = op_exp;
}


/******************************************************************************

	AllocValue

	�ϐ��̊m��

******************************************************************************/

VALUEINFO *AllocValue()
{
	VALUEINFO *vi;

	vi = mem_calloc(sizeof(VALUEINFO));
	if(vi == NULL){
		return NULL;
	}
	vi->v = mem_calloc(sizeof(VALUE));
	if(vi->v == NULL){
		mem_free(&vi);
		return NULL;
	}
	vi->v->vi = vi;
	return vi;
}


/******************************************************************************

	IndexToArray

	�C���f�b�N�X�Ŕz��v�f���擾

******************************************************************************/

static VALUEINFO *IndexToArray(EXECINFO *ei, VALUEINFO *pvi, int index)
{
	VALUEINFO *vi = pvi;
	VALUEINFO *kvi;
	int i = 0;

	if(index < 0){
		//�s���ȃC���f�b�N�X
		Error(ei, ERR_INDEX, ei->Err);
		return NULL;
	}

	if(vi->array == NULL){
		// 0 �Ԗڂ̒ǉ�
		vi = vi->array = AllocValue();
		if(vi == NULL){
			Error(ei, ERR_ALLOC, ei->Err);
			return NULL;
		}
		i = 1;
	}else{
		//�ʒu����
		for(vi = vi->array; vi != NULL; vi = vi->next, i++){
			if(i == index){
				return vi;
			}
			kvi = vi;
		}
		vi = kvi;
	}
	//����
	for(; i <= index; i++){
		vi = vi->next = AllocValue();
		if(vi == NULL){
			Error(ei, ERR_ALLOC, ei->Err);
			return NULL;
		}
	}
	return vi;
}


/******************************************************************************

	GetValueInt

	���l�̎擾

******************************************************************************/

long GetValueInt(VALUE *v)
{
	return v->iValue;
}


/******************************************************************************

	SetValue

	�l�̐ݒ�

******************************************************************************/

void SetValue(EXECINFO *ei, VALUE *to_v, VALUE *from_v)
{
	to_v->iValue = from_v->iValue;
}


/******************************************************************************

	GetLocalVariable

	���[�J���ϐ����擾

******************************************************************************/

VALUEINFO *GetLocalVariable(EXECINFO *ei, char *name)
{
	VALUEINFO *vi = NULL;

	//�ϐ��̌���
	for(; ei != NULL; ei = ei->parent){
		vi = FindValueInfo(ei->vi, name);
		if(vi != NULL){
			break;
		}
	}
	return vi;
}


/******************************************************************************

	SetLocalVariable

	���[�J���ϐ���ݒ�

******************************************************************************/

BOOL SetLocalVariable(EXECINFO *ei, char *name, VALUE *v)
{
	VALUEINFO *vi;

	//�ϐ��̐ݒ�
	vi = GetLocalVariable(ei, name);
	if(vi != NULL){
		SetValue(ei, vi->v, v);
		return TRUE;
	}
	return ((AddValueInfo(&(ei->vi), name, v) == NULL) ? FALSE : TRUE);
}


/******************************************************************************

	DeclVariable

	�ϐ���`

******************************************************************************/

static VALUEINFO *DeclVariable(EXECINFO *ei, char *name, char *err)
{
	VALUE v;

	if(FindValueInfo(ei->vi, name) != NULL){
		//�ϐ��̏d����`
		char *p = alloc_join(name, ERR_DECLARE);
		Error(ei, p, err);
		mem_free(&p);
		return NULL;
	}
	ZeroMemory(&v, sizeof(VALUE));
	return AddValueInfo(&(ei->vi), name, &v);
}


/******************************************************************************

	FindValueInfo

	�ϐ��̌���

******************************************************************************/

static VALUEINFO *FindValueInfo(VALUEINFO *vi, char *name)
{
	int name_hash;

	name_hash = str2hash(name);
	for(; vi != NULL; vi = vi->next){
		if(name_hash == vi->name_hash && tstrcmp(name, vi->Name) == 0){
			return vi;
		}
	}
	return NULL;
}


/******************************************************************************

	AddValueInfo

	�ϐ��̒ǉ�

******************************************************************************/

static VALUEINFO *AddValueInfo(VALUEINFO **vi_root, char *name, VALUE *v)
{
	VALUEINFO *vi;

	if(*vi_root == NULL){
		vi = *vi_root = AllocValue();
	}else{
		for(vi = *vi_root; vi->next != NULL; vi = vi->next);
		vi = vi->next = AllocValue();
	}
	if(vi == NULL){
		return NULL;
	}
	vi->Name = alloc_copy(name);
	if(v == NULL){
		vi->v->iValue = 0;
	}else{
		SetValue(NULL, vi->v, v);
	}
	vi->name_hash = str2hash(vi->Name);
	return vi;
}


/******************************************************************************

	CopyValueList

	�ϐ����X�g�̃R�s�[

******************************************************************************/

VALUEINFO *CopyValueList(VALUEINFO *From)
{
	VALUEINFO *To, Top;

	To = &Top;
	To->next = NULL;
	for(; From != NULL; From = From->next){
		To = To->next = AllocValue();
		if(To == NULL){
			return Top.next;
		}
		if(From->Name != NULL){
			To->Name = alloc_copy(From->Name);
			To->name_hash = From->name_hash;
		}
		To->v->iValue = From->v->iValue;
		To->array = CopyValueList(From->array);
	}
	return Top.next;
}


/******************************************************************************

	CopyValue

	�ϐ��̃R�s�[

******************************************************************************/

VALUEINFO *CopyValue(VALUEINFO *From)
{
	VALUEINFO *To;

	To = AllocValue();
	To->next = NULL;
	if(From->Name != NULL){
		To->Name = alloc_copy(From->Name);
		To->name_hash = From->name_hash;
	}
	To->v->iValue = From->v->iValue;
	To->array = CopyValueList(From->array);
	return To;
}


/******************************************************************************

	UnaryCalcValue

	�P�����Z�q�̌v�Z

******************************************************************************/

static VALUEINFO *UnaryCalcValue(EXECINFO *ei, VALUEINFO *vi, int c)
{
	VALUEINFO *vret;
	int i;

	i = GetValueInt(vi->v);
	switch(c)
	{
	case SYM_NOT:
		i = !i;
		break;

	case SYM_PLUS:
		i = +i;
		break;

	case SYM_MINS:
		i = -i;
		break;
	}
	vret = AllocValue();
	if(vret == NULL){
		Error(ei, ERR_ALLOC, ei->Err);
		return NULL;
	}
	vret->v->iValue = i;
	return vret;
}


/******************************************************************************

	IntegerCalcValue

	���l�^�̌v�Z

******************************************************************************/

static VALUEINFO *IntegerCalcValue(EXECINFO *ei, VALUEINFO *v1, VALUEINFO *v2, int c)
{
	VALUEINFO *vret;
	long i = 0, j;

	i = v1->v->iValue;
	j = v2->v->iValue;
	switch(c)
	{
	case SYM_DIV:
	case SYM_MOD:
		if(j == 0){
			Error(ei, ERR_DIVZERO, ei->Err);
			return NULL;
		}
		if(c == SYM_DIV){
			i /= j;
		}else{
			i %= j;
		}
		break;

	case SYM_MULTI: i *= j; break;
	case SYM_ADD: i += j; break;
	case SYM_SUB: i -= j; break;
	case SYM_CPAND: i = i && j; break;
	case SYM_CPOR: i = i || j; break;
	case SYM_EQEQ: i = i == j; break;
	case SYM_NTEQ: i = i != j; break;
	case SYM_LEFTEQ: i = i <= j; break;
	case SYM_LEFT: i = i < j; break;
	case SYM_RIGHTEQ: i = i >= j; break;
	case SYM_RIGHT: i = i > j; break;

	default:
		Error(ei, ERR_OPERATOR, ei->Err);
		return NULL;
	}

	vret = AllocValue();
	if(vret == NULL){
		Error(ei, ERR_ALLOC, ei->Err);
		return NULL;
	}
	vret->v->iValue = i;
	return vret;
}


/******************************************************************************

	ArrayCalcValue

	�z��̌v�Z

******************************************************************************/

static VALUEINFO *ArrayCalcValue(EXECINFO *ei, VALUEINFO *v1, VALUEINFO *v2, int c)
{
	VALUEINFO *vret;
	VALUEINFO *vi;
	long i = 0;

	switch(c)
	{
	case SYM_ADD:
		//�z��̘A��
		vret = AllocValue();
		if(vret == NULL){
			Error(ei, ERR_ALLOC, ei->Err);
			return NULL;
		}
		vret->array = CopyValueList(v1->array);
		if(vret->array != NULL){
			for(vi = vret->array; vi->next != NULL; vi = vi->next);
			//�A��
			vi->next = CopyValueList(v2->array);
		}else{
			vret->array = CopyValueList(v2->array);
		}
		return vret;

	case SYM_EQEQ:
	case SYM_NTEQ:
		//�z��̓��e��r
		for(v1 = v1->array, v2 = v2->array; v1 != NULL && v2 != NULL; v1 = v1->next, v2 = v2->next){
			vi = CalcValue(ei, v1, v2, SYM_EQEQ);
			i = vi->v->iValue;
			FreeValue(vi);
			if(i == 0){
				break;
			}
		}
		i = (v1 == NULL && v2 == NULL) ? 1 : 0;
		if(c == SYM_NTEQ){
			i = !i;
		}
		break;

	default:
		Error(ei, ERR_ARRAYOPERATOR, ei->Err);
		return NULL;
	}

	vret = AllocValue();
	if(vret == NULL){
		Error(ei, ERR_ALLOC, ei->Err);
		return NULL;
	}
	vret->v->iValue = i;
	return vret;
}


/******************************************************************************

	CalcValue

	�񍀉��Z�q�̌v�Z

******************************************************************************/

static VALUEINFO *CalcValue(EXECINFO *ei, VALUEINFO *v1, VALUEINFO *v2, int c)
{
	if(v1->array != NULL || v2->array != NULL){
		//�z��̌v�Z
		return ArrayCalcValue(ei, v1, v2, c);
	}
	//���l�^�̌v�Z
	return IntegerCalcValue(ei, v1, v2, c);
}


/******************************************************************************

	ExecSentense

	��͖؂̎��s

******************************************************************************/

int ExecSentense(EXECINFO *ei, TOKEN *cu_tk, VALUEINFO **retvi, VALUEINFO **retstack, LIBFUNC callback)
{
	EXECINFO cei;
	VALUEINFO *vi, *v1, *v2;
	VALUEINFO *stack = NULL;
	int RetSt = RET_SUCCESS;
	int cp;

	while(cu_tk != NULL && cu_tk->Type != ei->to_tk){
		ei->Err = cu_tk->Err;
		if (callback != NULL) {
			if (callback(ei, cu_tk) != 0) {
				RetSt = RET_EXIT;
				break;
			}
		}

		switch(cu_tk->Type)
		{
		case SYM_BOPEN:
			ZeroMemory(&cei, sizeof(EXECINFO));
			cei.sci = ei->sci;
			cei.lParam = ei->lParam;
			cei.parent = ei;
			vi = NULL;
			RetSt = ExecSentense(&cei, cu_tk->target, retvi, &vi, callback);
			FreeExecInfo(&cei);
			if(vi == NULL){
				break;
			}
			//���s��̃X�^�b�N�̓��e��z��ɐݒ�
			v1 = AllocValue();
			if(v1 == NULL){
				Error(ei, ERR_ALLOC, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			v1->array = vi;
			v1->next = stack;
			stack = v1;
			break;

		case SYM_LINEEND:
			//�X�^�b�N���������
			FreeValueList(stack);
			stack = NULL;
			break;

		case SYM_WORDEND:
			if(stack == NULL){
				//�X�^�b�N�ɋ�̒l��ǉ�
				stack = AllocValue();
				if(stack == NULL){
					Error(ei, ERR_ALLOC, ei->Err);
					RetSt = RET_ERROR;
					break;
				}
			}
			if(cu_tk->next != NULL && cu_tk->next->Type == SYM_WORDEND){
				//�X�^�b�N�ɋ�̒l��ǉ�
				vi = AllocValue();
				if(vi == NULL){
					Error(ei, ERR_ALLOC, ei->Err);
					RetSt = RET_ERROR;
					break;
				}
				vi->next = stack;
				stack = vi;
			}
			break;

		case SYM_JUMP:
			//�ړ�
			cu_tk = cu_tk->link;
			break;

		case SYM_EXIT:
			RetSt = RET_EXIT;
			if(retvi == NULL){
				break;
			}
			if(stack == NULL){
				break;
			}
			//�߂�l
			*retvi = AllocValue();
			if (*retvi == NULL) {
				Error(ei, ERR_ALLOC, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			vi = stack;
			stack = stack->next;
			SetValue(ei, (*retvi)->v, vi->v);
			(*retvi)->array = CopyValueList(vi->array);
			FreeValue(vi);
			break;

		case SYM_CMP:
			//��r
			if(stack == NULL){
				cu_tk = cu_tk->next;
				break;
			}
			//��r����
			vi = stack;
			stack = stack->next;
			cp = vi->v->iValue;
			FreeValue(vi);
			if(cp != 0){
				//�^
				//jump ELSE ���X�L�b�v
				cu_tk = cu_tk->next;
			}
			break;

		case SYM_ELSE:
		case SYM_CMPEND:
			break;

		case SYM_LOOP:
			//�J��Ԃ�
			if(stack != NULL){
				//��r����
				vi = stack;
				stack = stack->next;
				cp = vi->v->iValue;
				FreeValue(vi);
				if(cp == 0){
					//jump LOOPEND
					break;
				}
			}
			//���[�v�Ώۏ���
			RetSt = ExecSentense(ei, cu_tk->target, retvi, NULL, callback);
			if(RetSt != RET_SUCCESS){
				break;
			}
			//�p��
			cu_tk = cu_tk->next;
			RetSt = RET_SUCCESS;
			Sleep(0);
			//�㏈�� -> jump LOOPSTART
			break;

		case SYM_LOOPEND:
		case SYM_LOOPSTART:
			break;

		case SYM_DECLVARIABLE:
			//�ϐ���`
			v1 = DeclVariable(ei, cu_tk->buf, ei->Err);
			if(v1 == NULL){
				RetSt = RET_ERROR;
				break;
			}

			vi = AllocValue();
			if(vi == NULL){
				Error(ei, ERR_ALLOC, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			mem_free(&vi->v);
			vi->v = v1->v;
			vi->array = v1->array;
			vi->next = stack;
			stack = vi;
			break;

		case SYM_VARIABLE:
			//�ϐ��擾
			v1 = GetLocalVariable(ei, cu_tk->buf);
			if(v1 == NULL){
				if(ei->sci->explicit_val == TRUE){
					//�ϐ�������`
					char *err = alloc_join(cu_tk->buf, ERR_NOTDECLARE);
					Error(ei, err, ei->Err);
					mem_free(&err);
					RetSt = RET_ERROR;
					break;
				}
				//�ϐ����`
				v1 = DeclVariable(ei, cu_tk->buf, ei->Err);
				if(v1 == NULL){
					RetSt = RET_ERROR;
					break;
				}
			}
			vi = AllocValue();
			if(vi == NULL){
				Error(ei, ERR_ALLOC, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			if(retstack != NULL){
				vi->Name = alloc_copy(v1->Name);
				vi->name_hash = v1->name_hash;
			}
			mem_free(&vi->v);
			vi->v = v1->v;
			vi->array = v1->array;
			vi->next = stack;
			stack = vi;
			break;

		case SYM_ARRAY:
			//�z��
			if(stack == NULL || stack->next == NULL){
				Error(ei, ERR_SENTENCE, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			v1 = stack;
			stack = stack->next;
			v2 = stack;
			stack = stack->next;

			vi = IndexToArray(ei, v2->v->vi, v1->v->iValue);
			if(vi == NULL){
				FreeValue(v1);
				FreeValue(v2);
				RetSt = RET_ERROR;
				break;
			}
			FreeValue(v1);

			v1 = AllocValue();
			if(v1 == NULL){
				FreeValue(v2);
				Error(ei, ERR_ALLOC, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			if(v2->v != NULL && v2->v->vi == v2){
				//�萔�̏ꍇ�̓R�s�[
				SetValue(ei, v1->v, vi->v);
				v1->v->vi->array = CopyValueList(vi->array);
			}else{
				//�ϐ����̒l�̎Q��
				mem_free(&v1->v);
				v1->v = vi->v;
				v1->array = vi->array;
			}
			v1->next = stack;
			stack = v1;
			FreeValue(v2);
			break;

		case SYM_CONST:
			//���l�萔
			vi = AllocValue();
			if(vi == NULL){
				Error(ei, ERR_ALLOC, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			vi->v->iValue = cu_tk->i;

			vi->next = stack;
			stack = vi;
			break;

		case SYM_NOT:
		case SYM_PLUS:
		case SYM_MINS:
			//�P�����Z�q
			if(stack == NULL){
				Error(ei, ERR_SENTENCE, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			vi = stack;
			stack = stack->next;

			v1 = UnaryCalcValue(ei, vi, cu_tk->Type);
			if(v1 != vi){
				FreeValue(vi);
			}
			if(v1 == NULL){
				RetSt = RET_ERROR;
				break;
			}
			v1->next = stack;
			stack = v1;
			break;

		case SYM_EQ:
			//������Z�q
			if(stack == NULL || stack->next == NULL){
				Error(ei, ERR_SENTENCE, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			//�E��
			v1 = stack;
			stack = stack->next;
			//����
			v2 = stack;
			stack = stack->next;

			if(v1->v->vi->array != NULL){
				//�z��̃R�s�[
				FreeValueList(v2->v->vi->array);
				v2->v->vi->array = CopyValueList(v1->array);
			}else{
				//�ϐ��ɒl��ݒ�
				SetValue(ei, v2->v, v1->v);
				FreeValueList(v2->v->vi->array);
				v2->v->vi->array = NULL;
			}
			if(retstack != NULL){
				mem_free(&v1->Name);
				v1->Name = alloc_copy(v2->Name);
				v1->name_hash = v2->name_hash;
			}
			//��������l���X�^�b�N�ɐς�
			v1->next = stack;
			stack = v1;
			FreeValue(v2);
			break;

		default:
			//�񍀉��Z�q
			if(stack == NULL || stack->next == NULL){
				Error(ei, ERR_SENTENCE, ei->Err);
				RetSt = RET_ERROR;
				break;
			}
			v1 = stack;
			stack = stack->next;
			v2 = stack;
			stack = stack->next;

			vi = CalcValue(ei, v2, v1, cu_tk->Type);
			if(vi == NULL){
				RetSt = RET_ERROR;
				break;
			}
			FreeValue(v1);
			FreeValue(v2);

			//���Z���ʂ��X�^�b�N�ɐς�
			vi->next = stack;
			stack = vi;
			break;
		}
		if(RetSt != RET_SUCCESS){
			break;
		}
		cu_tk = cu_tk->next;
	}

	if(retstack != NULL){
		//�X�^�b�N��Ԃ�
		*retstack = NULL;
		while(stack != NULL){
			vi = stack;
			stack = stack->next;
			vi->next = *retstack;
			*retstack = vi;
		}
	}else{
		//�X�^�b�N���������
		FreeValueList(stack);
	}
	return RetSt;
}


/******************************************************************************

	ExecScript

	�X�N���v�g�̎��s

******************************************************************************/

int ExecScript(SCRIPTINFO *sci, VALUEINFO **vi, LIBFUNC callback)
{
	EXECINFO ei;

	ZeroMemory(&ei, sizeof(EXECINFO));
	ei.Name = sci->name;
	ei.sci = sci;
	ei.vi = sci->vi;
	sci->vi = NULL;
	if(ExecSentense(&ei, sci->tk, vi, NULL, callback) == RET_ERROR){
		FreeExecInfo(&ei);
		return -1;
	}
	if (callback != NULL) {
		callback(&ei, NULL);
	}
	FreeExecInfo(&ei);
	return 0;
}
/* End of source */
